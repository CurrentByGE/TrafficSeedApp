# Predix Cloud Foundry Credentials
# Keep all values inside double quotes

#########################################################
# Mandatory User configurations that need to be updated
#########################################################

############## Proxy Configurations #############

# Proxy settings in format proxy_host:proxy_port
# Leave as is if no proxy
ALL_PROXY=""

############## Front End Configurations #############

# Name for your Frone End Application
FRONT_END_APP_NAME="svc-test"

########### Cloud Foundry (CF) Configurations ###########

# CF Organization
CF_ORG="susheel.choudhari@ge.com"

# CF Username
CF_USERNAME="susheel.choudhari@ge.com"

############### UAA Configurations ###############

# The username of the new user to authenticate with the application
UAA_USER_NAME="susheelvc"

# The email address of username above
UAA_USER_EMAIL="susheel.choudhari@ge.com"

# The password of the user above
UAA_USER_PASSWORD="iluJiya132"

# The secret of the Admin client ID (Administrator Credentails)
UAA_ADMIN_SECRET="predix@pp"

# The generic client ID that will be created with necessary UAA scope/autherities
UAA_CLIENTID_GENERIC="test_admin"

# The generic client ID password
UAA_CLIENTID_GENERIC_SECRET="secret"

############# Predix Asset Configurations #############

# Name of the "Asset" that is recorded to Predix Asset
ASSET_TYPE="/assset/raspberrypi1"

# Name of the tag (Asset name ex: Wind Turbine) you want to ingest to timeseries with. NO SPACES
ASSET_TAG="temperature"

#Description of the Machine that is recorded to Predix Asset
ASSET_DESCRIPTION="Edison board"

###############################
# Optional configurations
###############################

# GITHUB repo to pull predix-nodejs-starter
# Use this one for the non-internal GE repo = https://github.build.ge.com/adoption/predix-nodejs-starter
GIT_PREDIX_NODEJS_STARTER_URL="git@github.build.ge.com:adoption/predix-nodejs-starter.git"

# Name for the temp_app application
TEMP_APP="svc-app"

########### Cloud Foundry (CF) Configurations ###########

# Cloud Foundry Host Domain Name - default already set
CF_HOST="api.system.aws-usw02-pr.ice.predix.io"

# Could Foundry Space - default already set
CF_SPACE="dev"

############### UAA Configurations ###############

# The name of the UAA service you are binding to - default already set
UAA_SERVICE_NAME="predix-uaa"

# Name of the UAA plan (eg: Free) - default already set
UAA_PLAN="Tiered"

# Name of your UAA instance - default already set
UAA_INSTANCE_NAME="predix-ref-app-uaa"

############# Predix TimeSeries Configurations ##############

#The name of the TimeSeries service you are binding to - default already set
TIMESERIES_SERVICE_NAME="predix-timeseries"

#Name of the TimeSeries plan (eg: Free) - default already set
TIMESERIES_SERVICE_PLAN="Bronze"

#Name of your TimeSeries instance - default already set
TIMESERIES_INSTANCE_NAME="predix-ref-app-timeseries"

############# Predix Asset Configurations ##############

#The name of the Asset service you are binding to - default already set
ASSET_SERVICE_NAME="predix-asset"

#Name of the Asset plan (eg: Free) - default already set
ASSET_SERVICE_PLAN="Tiered"

#Name of your Asset instance - default already set
ASSET_INSTANCE_NAME="predix-ref-app-asset"

#Target Device to transfer the Predix Machine
TARGETDEVICE="edison"

#Target Device IP
TARGETDEVICEIP="192.168.1.229"

#Target Device User
TARGETDEVICEUSER="root"

#Predix Machine Home Dir
PREDIXMACHINEHOME=PredixMachine_16.2.0-SNAPSHOT

